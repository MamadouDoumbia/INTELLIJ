/*
 * LoadRunner Java script. (Build: 3020)
 * 
 * Script Description: 
 *                     
 */

import lrapi.lr;


import com.example.Customer;
import com.example.Afro;
import com.example.Euro;
import com.example.PhoneNumber;
import com.example.Account;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;


import org.apache.avro.AvroRuntimeException;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.*;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import java.io.File;
	
	
/*-------------------
	List
/*-----------------*/
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;


public class Actions
{

	public int init() throws Throwable {
		
		return 0;
	}//end of init


	public int action() throws Throwable {
		
		
        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
        properties.setProperty("acks", "all");
        properties.setProperty("retries", "10");
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");
        

 Producer<String, Customer> producer = new KafkaProducer<String, Customer>(properties);

        String topic = "Fafo_Topic";
        
    Account compte = Account.newBuilder().setAccountNumber("mo").setId("Paris").build();
    List<Account> list = new ArrayList<>();

    
		list.add(compte);
   
      System.out.println("List :"+ Account.newBuilder());                          	
      System.out.println("List :"+ compte);
      System.out.println("List :"+ list);

       	
        Customer bob = Customer.newBuilder().setAfro(
                        Afro.newBuilder()
					.setAge(34)
                	.setAutomatedEmail(false)
                	.setFirstName("John")
                	.setLastName("Doe")
                	.setHeight(178f)
                	.setWeight(75f).build()).setEuro(
                        Euro.newBuilder()
					.setAge(34)
                	.setAutomatedEmail(false)
                	.setFirstName("John")
                	.setLastName("Doe")
                	.setHeight(178f)
                	.setWeight(75f)
                	.setAccountList(list)
                	.setPhoneNumber(
                        PhoneNumber.newBuilder()
                                .setAreaCode("301")
                                .setCountryCode("1")
                                .setPrefix("555")
                                .setNumber("1234")
                                .build())
                	.build())
                .build();
      

        
        System.out.println("Mon est :"+ bob);
        System.out.println("Mon est :");
        
        ProducerRecord<String, Customer> producerRecord = new ProducerRecord<String, Customer>(
                topic, bob
        );

        System.out.println(bob);
        producer.send(producerRecord);
        
		return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end
}
